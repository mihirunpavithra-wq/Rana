import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Portfolio from './components/Portfolio';
import About from './components/About';
import Packages from './components/Packages';
import BookingCalendar from './components/BookingCalendar';
import Testimonials from './components/Testimonials';
import Contact from './components/Contact';
import Footer from './components/Footer';
import { photographerConfig } from './data/portfolioData';
import { MessageCircle } from 'lucide-react';

export default function App() {
  const [selectedPackage, setSelectedPackage] = useState('');

  const handleSelectPackage = (packageName) => {
    setSelectedPackage(packageName);
    const calendarSection = document.getElementById('calendar');
    if (calendarSection) {
      calendarSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#090a0f] text-slate-100 flex flex-col font-sans selection:bg-amber-400 selection:text-black">
      {/* Sticky Top Navbar */}
      <Navbar />

      <main className="flex-grow">
        {/* Hero Section */}
        <Hero />

        {/* Portfolio Gallery Section */}
        <Portfolio />

        {/* About Rana & Philosophy */}
        <About />

        {/* Photography Packages & Pricing */}
        <Packages onSelectPackage={handleSelectPackage} />

        {/* Availability Calendar & WhatsApp Booking Flow */}
        <BookingCalendar preselectedPackage={selectedPackage} />

        {/* Client Testimonials */}
        <Testimonials />

        {/* Contact & Studio Details */}
        <Contact />
      </main>

      {/* Footer */}
      <Footer />

      {/* Floating WhatsApp Quick Action Button */}
      <a
        href={`https://wa.me/${photographerConfig.whatsappNumber}?text=Hi%20Rana,%20I'm%20visiting%20your%20website%20and%20would%20love%20to%20chat%20about%20a%20photography%20booking!`}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-40 p-4 rounded-full bg-gradient-to-tr from-emerald-600 to-green-500 hover:from-emerald-500 hover:to-green-400 text-white shadow-2xl shadow-green-950/60 hover:scale-110 active:scale-95 transition-all duration-300 group flex items-center gap-2"
        title="Direct Chat on WhatsApp"
        aria-label="Direct Chat on WhatsApp"
      >
        <MessageCircle className="w-6 h-6 fill-white" />
        <span className="hidden group-hover:inline-block text-xs font-bold tracking-wider uppercase pr-1 transition-all">
          Chat with Rana
        </span>
      </a>
    </div>
  );
}
