import React, { useState, useEffect } from 'react';
import { Camera, Calendar, Menu, X, MessageCircle } from 'lucide-react';
import { photographerConfig } from '../data/portfolioData';

export default function Navbar({ onOpenCalendarModal }) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'Portfolio', href: '#portfolio' },
    { name: 'About Rana', href: '#about' },
    { name: 'Packages', href: '#packages' },
    { name: 'Check Dates', href: '#calendar' },
    { name: 'Testimonials', href: '#testimonials' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'py-3 shadow-2xl border-b border-white/10'
          : 'py-5 bg-gradient-to-b from-black/70 via-black/30 to-transparent'
      }`}
      style={scrolled ? { backgroundColor: 'rgba(30,42,56,0.95)', backdropFilter: 'blur(12px)' } : {}}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">

          {/* Logo */}
          <a href="#home" className="flex items-center gap-3 group">
            <div className="w-10 h-10 rounded-full p-[1.5px] transition-transform duration-300 group-hover:scale-105"
              style={{ background: 'linear-gradient(135deg, #3A6A6B, #89B7C2)' }}>
              <div className="w-full h-full rounded-full flex items-center justify-center" style={{ backgroundColor: '#1e2a38' }}>
                <Camera className="w-5 h-5 transition-transform group-hover:rotate-12 duration-300" style={{ color: '#89B7C2' }} />
              </div>
            </div>
            <div>
              <span className="font-cinzel text-xl sm:text-2xl font-bold tracking-wider text-white group-hover:text-[#89B7C2] transition-colors">
                Rana's Story
              </span>
              <span className="block text-[10px] uppercase tracking-widest font-medium -mt-1" style={{ color: '#89B7C2' }}>
                Photography & Films
              </span>
            </div>
          </a>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-7">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-sm font-medium text-slate-300 transition-colors relative py-1 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[2px] after:transition-all after:duration-300 hover:after:w-full"
                style={{ '--tw-hover-color': '#89B7C2' }}
                onMouseEnter={e => e.target.style.color = '#89B7C2'}
                onMouseLeave={e => e.target.style.color = ''}
              >
                {link.name}
              </a>
            ))}
          </nav>

          {/* CTAs */}
          <div className="hidden lg:flex items-center gap-3">
            <a
              href="#calendar"
              className="flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold uppercase tracking-wider text-slate-200 border transition-all"
              style={{ borderColor: 'rgba(137,183,194,0.4)', backgroundColor: 'rgba(73,132,150,0.15)' }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = '#89B7C2'; e.currentTarget.style.color = '#89B7C2'; }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = 'rgba(137,183,194,0.4)'; e.currentTarget.style.color = ''; }}
            >
              <Calendar className="w-3.5 h-3.5" style={{ color: '#89B7C2' }} />
              <span>Check Availability</span>
            </a>

            <a
              href={`https://wa.me/${photographerConfig.whatsappNumber}?text=Hi%20Rana,%20I'm%20interested%20in%20booking%20your%20photography%20services!`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold uppercase tracking-wider text-white shadow-lg hover:scale-105 active:scale-95 transition-all"
              style={{ background: 'linear-gradient(135deg, #3A6A6B, #498496)' }}
            >
              <MessageCircle className="w-4 h-4 fill-white" />
              <span>WhatsApp</span>
            </a>
          </div>

          {/* Mobile Icons */}
          <div className="flex md:hidden items-center gap-2">
            <a
              href={`https://wa.me/${photographerConfig.whatsappNumber}`}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-full text-white"
              style={{ backgroundColor: '#3A6A6B' }}
            >
              <MessageCircle className="w-4 h-4" />
            </a>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-300 hover:text-white focus:outline-none"
            >
              {mobileMenuOpen
                ? <X className="w-6 h-6" style={{ color: '#89B7C2' }} />
                : <Menu className="w-6 h-6" />
              }
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-white/10 px-6 py-6 space-y-4"
          style={{ backgroundColor: 'rgba(30,42,56,0.98)', backdropFilter: 'blur(16px)' }}>
          <div className="grid gap-3">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className="text-base font-medium text-slate-200 py-1 border-b border-white/5 transition-colors"
                onMouseEnter={e => e.target.style.color = '#89B7C2'}
                onMouseLeave={e => e.target.style.color = ''}
              >
                {link.name}
              </a>
            ))}
          </div>
          <div className="pt-2 flex flex-col gap-3">
            <a
              href="#calendar"
              onClick={() => setMobileMenuOpen(false)}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-lg text-sm font-semibold uppercase tracking-wider border"
              style={{ color: '#89B7C2', borderColor: 'rgba(137,183,194,0.4)', backgroundColor: 'rgba(73,132,150,0.15)' }}
            >
              <Calendar className="w-4 h-4" />
              Check Booked Dates
            </a>
            <a
              href={`https://wa.me/${photographerConfig.whatsappNumber}`}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setMobileMenuOpen(false)}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-lg text-sm font-semibold uppercase tracking-wider text-white shadow-lg"
              style={{ background: 'linear-gradient(135deg, #3A6A6B, #498496)' }}
            >
              <MessageCircle className="w-4 h-4 fill-white" />
              Direct WhatsApp Booking
            </a>
          </div>
        </div>
      )}
    </header>
  );
}
