import React from 'react';
import { testimonials } from '../data/portfolioData';
import { Star, Quote } from 'lucide-react';

export default function Testimonials() {
  return (
    <section id="testimonials" className="py-24 relative" style={{ backgroundColor: '#243044' }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs uppercase tracking-widest font-semibold" style={{ color: '#89B7C2' }}>
            Kind Words • Real Stories
          </span>
          <h2 className="font-cinzel text-3xl sm:text-5xl font-bold text-white mt-3 mb-4">
            Words from Our Couples
          </h2>
          <div className="w-16 h-1 mx-auto mb-6 rounded-full"
            style={{ background: 'linear-gradient(90deg, #3A6A6B, #89B7C2)' }} />
          <p className="text-sm sm:text-base font-light" style={{ color: '#9bb5bf' }}>
            We are honored to have documented memories for so many wonderful couples.
          </p>
        </div>

        {/* Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((item) => (
            <div
              key={item.id}
              className="p-8 rounded-3xl flex flex-col justify-between relative group transition-all border"
              style={{ backgroundColor: 'rgba(255,255,255,0.03)', borderColor: 'rgba(137,183,194,0.1)' }}
              onMouseEnter={e => e.currentTarget.style.borderColor = 'rgba(73,132,150,0.4)'}
              onMouseLeave={e => e.currentTarget.style.borderColor = 'rgba(137,183,194,0.1)'}
            >
              <div>
                <Quote className="w-8 h-8 mb-4 transition-colors"
                  style={{ color: 'rgba(73,132,150,0.4)' }}
                  onMouseEnter={e => e.target.style.color = '#498496'}
                />

                {/* Stars */}
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(item.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4" style={{ fill: '#89B7C2', color: '#89B7C2' }} />
                  ))}
                </div>

                <p className="text-sm sm:text-base italic leading-relaxed font-light mb-6" style={{ color: '#9bb5bf' }}>
                  "{item.review}"
                </p>
              </div>

              {/* Author */}
              <div className="flex items-center gap-3 pt-4 border-t" style={{ borderColor: 'rgba(137,183,194,0.1)' }}>
                <img
                  src={item.avatar}
                  alt={item.couple}
                  className="w-12 h-12 rounded-full object-cover border"
                  style={{ borderColor: 'rgba(73,132,150,0.5)' }}
                />
                <div>
                  <h4 className="font-serif-display font-bold text-white text-base">{item.couple}</h4>
                  <p className="text-xs font-medium" style={{ color: '#89B7C2' }}>{item.event}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
