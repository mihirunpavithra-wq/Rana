import React from 'react';
import { photographerConfig } from '../data/portfolioData';
import { Camera, Award, Clock, HeartHandshake, Film, Sparkles, CheckCircle2 } from 'lucide-react';

export default function About() {
  const highlights = [
    { icon: Camera, title: "Candid & Soulful Approach", desc: "No awkward forced poses. We capture natural moments, laughter, happy tears, and heartfelt connections." },
    { icon: Film, title: "Cinema-Grade Coloring", desc: "Each photo undergoes bespoke color grading with rich skin tones and timeless, filmic color palettes." },
    { icon: Clock, title: "Fast Sneak-Peeks", desc: "Receive selected high-resolution highlight photos within 48 hours for your Instagram & family shares." },
    { icon: HeartHandshake, title: "Friendly Guidance", desc: "From location scouting to timeline planning, Rana works closely with you to make your day effortless." }
  ];

  const gearList = [
    "Sony Alpha Full-Frame Bodies",
    "Sony G-Master 24-70mm f/2.8 & 85mm f/1.4",
    "DJI Drone 4K Aerial Perspectives",
    "Profoto & Godox Off-Camera Lighting",
    "Dual Memory Card Backup System"
  ];

  return (
    <section id="about" className="py-24 relative overflow-hidden" style={{ backgroundColor: '#1e2a38' }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">

          {/* Left: Photographer Portrait */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-md lg:max-w-none">
              <div className="absolute -inset-4 rounded-3xl blur-xl"
                style={{ background: 'linear-gradient(135deg, rgba(58,106,107,0.25), rgba(90,60,98,0.15))' }} />
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border aspect-[3/4]"
                style={{ borderColor: 'rgba(137,183,194,0.2)', backgroundColor: '#2a3650' }}>
                <img
                  src="https://images.unsplash.com/photo-1554048612-b6a482bc67e5?auto=format&fit=crop&w=800&q=80"
                  alt="Rana - Lead Photographer"
                  className="w-full h-full object-cover"
                  style={{ filter: 'contrast(1.05)' }}
                />
                <div className="absolute inset-0"
                  style={{ background: 'linear-gradient(to top, rgba(30,42,56,0.85) 0%, rgba(56,68,102,0.2) 50%, transparent 100%)' }} />

                {/* Floating Badge */}
                <div className="absolute bottom-6 left-6 right-6 p-4 rounded-xl backdrop-blur-md border"
                  style={{ backgroundColor: 'rgba(30,42,56,0.85)', borderColor: 'rgba(137,183,194,0.2)' }}>
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-lg" style={{ backgroundColor: '#3A6A6B' }}>
                      <Award className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <div className="text-white font-cinzel font-bold text-lg">
                        {photographerConfig.photographerName}
                      </div>
                      <div className="text-xs uppercase tracking-wider font-medium" style={{ color: '#89B7C2' }}>
                        {photographerConfig.title}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Bio & Story */}
          <div className="lg:col-span-7">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full text-xs uppercase tracking-wider font-semibold mb-4 border"
              style={{ backgroundColor: 'rgba(73,132,150,0.15)', borderColor: 'rgba(137,183,194,0.3)', color: '#89B7C2' }}>
              <Sparkles className="w-3.5 h-3.5" style={{ color: '#89B7C2' }} />
              <span>Behind The Lens</span>
            </div>

            <h2 className="font-cinzel text-3xl sm:text-5xl font-bold text-white mb-6 leading-tight">
              Capturing Love As It <br />
              <span className="text-gradient-sky">Naturally Happens</span>
            </h2>

            <p className="text-base sm:text-lg font-light leading-relaxed mb-6" style={{ color: '#9bb5bf' }}>
              {photographerConfig.bio}
            </p>

            <p className="text-sm sm:text-base leading-relaxed mb-8" style={{ color: '#7a9faf' }}>
              Whether you are planning an intimate beach sunset vow in Mirissa, a grand Kandyan Poruwa ceremony in the hill country, or a chic church celebration in Colombo, my team and I focus on the genuine moments between you and your loved ones.
            </p>

            {/* Highlights Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
              {highlights.map((item, idx) => {
                const Icon = item.icon;
                return (
                  <div key={idx}
                    className="p-4 rounded-xl border transition-colors"
                    style={{ backgroundColor: 'rgba(255,255,255,0.03)', borderColor: 'rgba(137,183,194,0.1)' }}
                    onMouseEnter={e => e.currentTarget.style.borderColor = 'rgba(73,132,150,0.4)'}
                    onMouseLeave={e => e.currentTarget.style.borderColor = 'rgba(137,183,194,0.1)'}
                  >
                    <div className="flex items-center gap-2.5 mb-1.5">
                      <Icon className="w-4 h-4" style={{ color: '#89B7C2' }} />
                      <h4 className="text-white font-medium text-sm">{item.title}</h4>
                    </div>
                    <p className="text-xs leading-normal" style={{ color: '#7a9faf' }}>{item.desc}</p>
                  </div>
                );
              })}
            </div>

            {/* Gear */}
            <div className="p-4 rounded-xl border" style={{ backgroundColor: 'rgba(58,106,107,0.1)', borderColor: 'rgba(73,132,150,0.25)' }}>
              <div className="text-xs uppercase tracking-wider font-semibold mb-2" style={{ color: '#89B7C2' }}>
                Professional Gear & Dual Redundancy
              </div>
              <div className="flex flex-wrap gap-x-4 gap-y-1.5 text-xs" style={{ color: '#9bb5bf' }}>
                {gearList.map((gear, idx) => (
                  <div key={idx} className="flex items-center gap-1.5">
                    <CheckCircle2 className="w-3 h-3" style={{ color: '#3A6A6B' }} />
                    <span>{gear}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
