import React, { useState } from 'react';
import { portfolioItems, categories } from '../data/portfolioData';
import { MapPin, Maximize2, X, ChevronLeft, ChevronRight, Calendar } from 'lucide-react';

export default function Portfolio() {
  const [activeCategory, setActiveCategory] = useState('all');
  const [selectedPhotoIndex, setSelectedPhotoIndex] = useState(null);

  const filteredItems = activeCategory === 'all'
    ? portfolioItems
    : portfolioItems.filter(item => item.category === activeCategory);

  const openLightbox = (index) => setSelectedPhotoIndex(index);
  const closeLightbox = () => setSelectedPhotoIndex(null);
  const nextPhoto = () => setSelectedPhotoIndex((selectedPhotoIndex + 1) % filteredItems.length);
  const prevPhoto = () => setSelectedPhotoIndex((selectedPhotoIndex - 1 + filteredItems.length) % filteredItems.length);

  const currentPhoto = selectedPhotoIndex !== null ? filteredItems[selectedPhotoIndex] : null;

  return (
    <section id="portfolio" className="py-24 relative" style={{ backgroundColor: '#243044' }}>
      {/* Decorative glows */}
      <div className="absolute top-0 left-1/4 w-96 h-96 rounded-full blur-3xl pointer-events-none"
        style={{ backgroundColor: 'rgba(58,106,107,0.08)' }} />
      <div className="absolute bottom-0 right-1/4 w-96 h-96 rounded-full blur-3xl pointer-events-none"
        style={{ backgroundColor: 'rgba(90,60,98,0.08)' }} />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">

        {/* Heading */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-xs uppercase tracking-widest font-semibold" style={{ color: '#89B7C2' }}>
            Captured Stories • Previous Work
          </span>
          <h2 className="font-cinzel text-3xl sm:text-5xl font-bold text-white mt-3 mb-4">
            Our Portfolio & Gallery
          </h2>
          <div className="w-16 h-1 mx-auto mb-6 rounded-full"
            style={{ background: 'linear-gradient(90deg, #3A6A6B, #89B7C2)' }} />
          <p className="text-sm sm:text-base font-light leading-relaxed" style={{ color: '#9bb5bf' }}>
            Every couple is unique, every wedding is a once-in-a-lifetime tale.
            Browse through some of our favourite captured moments across Sri Lanka.
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 mb-12">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className="px-5 py-2.5 rounded-full text-xs sm:text-sm font-medium tracking-wide transition-all"
              style={
                activeCategory === cat.id
                  ? { background: 'linear-gradient(135deg, #3A6A6B, #498496)', color: '#fff', boxShadow: '0 4px 15px rgba(73,132,150,0.3)', transform: 'scale(1.05)' }
                  : { backgroundColor: 'rgba(255,255,255,0.05)', color: '#9bb5bf', border: '1px solid rgba(137,183,194,0.2)' }
              }
              onMouseEnter={e => { if (activeCategory !== cat.id) e.currentTarget.style.borderColor = 'rgba(137,183,194,0.5)'; }}
              onMouseLeave={e => { if (activeCategory !== cat.id) e.currentTarget.style.borderColor = 'rgba(137,183,194,0.2)'; }}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item, index) => (
            <div
              key={item.id}
              className="group relative rounded-2xl overflow-hidden shadow-xl cursor-pointer gallery-img-container aspect-[4/5] border border-white/5"
              style={{ backgroundColor: '#2a3650' }}
              onClick={() => openLightbox(index)}
            >
              <img
                src={item.image}
                alt={item.title}
                loading="lazy"
                className="w-full h-full object-cover gallery-img"
              />
              {/* Overlay */}
              <div className="absolute inset-0 opacity-75 group-hover:opacity-90 transition-opacity duration-300"
                style={{ background: 'linear-gradient(to top, rgba(30,42,56,0.95) 0%, rgba(56,68,102,0.3) 50%, transparent 100%)' }} />

              {/* Zoom icon */}
              <div className="absolute top-4 right-4 p-2 rounded-full backdrop-blur-md opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-2 group-hover:translate-y-0"
                style={{ backgroundColor: 'rgba(30,42,56,0.7)' }}>
                <Maximize2 className="w-4 h-4" style={{ color: '#89B7C2' }} />
              </div>

              {/* Bottom Info */}
              <div className="absolute bottom-0 inset-x-0 p-6 flex flex-col justify-end">
                <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wider mb-1" style={{ color: '#89B7C2' }}>
                  <span>{item.client}</span>
                  <span>•</span>
                  <span className="capitalize">{item.category}</span>
                </div>
                <h3 className="font-serif-display text-xl font-bold text-white group-hover:text-[#89B7C2] transition-colors">
                  {item.title}
                </h3>
                <div className="flex items-center gap-1.5 text-xs mt-2" style={{ color: '#9bb5bf' }}>
                  <MapPin className="w-3.5 h-3.5 shrink-0" style={{ color: '#89B7C2' }} />
                  <span className="truncate">{item.location}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* CTA Under Gallery */}
        <div className="mt-16 text-center">
          <p className="text-sm mb-4" style={{ color: '#6a8fa0' }}>
            Love this aesthetic? Check if your date is open in Rana's schedule.
          </p>
          <a
            href="#calendar"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-full text-sm font-semibold tracking-wider uppercase transition-all border"
            style={{ color: '#89B7C2', borderColor: 'rgba(137,183,194,0.4)', backgroundColor: 'rgba(73,132,150,0.1)' }}
            onMouseEnter={e => e.currentTarget.style.backgroundColor = 'rgba(73,132,150,0.2)'}
            onMouseLeave={e => e.currentTarget.style.backgroundColor = 'rgba(73,132,150,0.1)'}
          >
            <Calendar className="w-4 h-4" />
            <span>Check Calendar Availability Now</span>
          </a>
        </div>
      </div>

      {/* Lightbox */}
      {selectedPhotoIndex !== null && currentPhoto && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6"
          style={{ backgroundColor: 'rgba(15,20,35,0.97)', backdropFilter: 'blur(16px)' }}>
          <button onClick={closeLightbox}
            className="absolute top-5 right-5 p-2 rounded-full text-white z-50 border border-white/20 transition-colors"
            style={{ backgroundColor: 'rgba(255,255,255,0.1)' }}
            onMouseEnter={e => e.currentTarget.style.backgroundColor = 'rgba(73,132,150,0.4)'}
            onMouseLeave={e => e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.1)'}>
            <X className="w-6 h-6" />
          </button>

          <button onClick={(e) => { e.stopPropagation(); prevPhoto(); }}
            className="absolute left-4 top-1/2 -translate-y-1/2 p-3 rounded-full text-white z-50 border border-white/20 transition-colors"
            style={{ backgroundColor: 'rgba(255,255,255,0.1)' }}
            onMouseEnter={e => e.currentTarget.style.backgroundColor = 'rgba(73,132,150,0.4)'}
            onMouseLeave={e => e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.1)'}>
            <ChevronLeft className="w-6 h-6" />
          </button>

          <button onClick={(e) => { e.stopPropagation(); nextPhoto(); }}
            className="absolute right-4 top-1/2 -translate-y-1/2 p-3 rounded-full text-white z-50 border border-white/20 transition-colors"
            style={{ backgroundColor: 'rgba(255,255,255,0.1)' }}
            onMouseEnter={e => e.currentTarget.style.backgroundColor = 'rgba(73,132,150,0.4)'}
            onMouseLeave={e => e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.1)'}>
            <ChevronRight className="w-6 h-6" />
          </button>

          <div className="max-w-4xl max-h-[85vh] flex flex-col items-center justify-center">
            <img
              src={currentPhoto.image}
              alt={currentPhoto.title}
              className="max-h-[65vh] w-auto max-w-full object-contain rounded-xl shadow-2xl border border-white/10"
            />
            <div className="mt-5 text-center max-w-xl px-4">
              <h3 className="font-serif-display text-2xl font-bold text-white">{currentPhoto.title}</h3>
              <p className="text-sm font-medium mt-1" style={{ color: '#89B7C2' }}>
                {currentPhoto.client} • {currentPhoto.location}
              </p>
              <p className="text-xs sm:text-sm mt-2 font-light" style={{ color: '#9bb5bf' }}>
                {currentPhoto.description}
              </p>
              <div className="mt-4">
                <a
                  href="#calendar"
                  onClick={closeLightbox}
                  className="px-5 py-2 rounded-full text-white text-xs font-bold uppercase tracking-wider transition-colors"
                  style={{ background: 'linear-gradient(135deg, #3A6A6B, #498496)' }}
                >
                  Book Your Shoot With Rana
                </a>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
