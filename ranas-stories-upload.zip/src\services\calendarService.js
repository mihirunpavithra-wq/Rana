/**
 * Google Calendar & Availability Service for Rana's Story
 * 
 * Supports:
 * 1. Live Google Calendar iCal (.ics) public feed parsing.
 * 2. Pre-configured booked dates (Sri Lankan wedding season demo & custom bookings).
 * 3. LocalStorage persistence so Rana can test or toggle dates easily.
 * 4. Automatic sync with Google Calendar.
 */

// Helper to format Date to YYYY-MM-DD
export const formatDateKey = (date) => {
  const d = new Date(date);
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

// Default booked dates for demonstration (upcoming wedding dates in 2026)
const DEFAULT_BOOKED_EVENTS = [
  { date: "2026-10-24", title: "Wedding - Kandy (Booked)" },
  { date: "2026-10-25", title: "Homecoming - Colombo (Booked)" },
  { date: "2026-10-31", title: "Pre-Shoot - Mirissa (Booked)" },
  { date: "2026-11-07", title: "Royal Wedding - Galle Face Hotel (Booked)" },
  { date: "2026-11-08", title: "Homecoming - Negombo (Booked)" },
  { date: "2026-11-14", title: "Wedding - Earl's Regency Kandy (Booked)" },
  { date: "2026-11-21", title: "Destination Shoot - Nuwara Eliya (Booked)" },
  { date: "2026-11-28", title: "Wedding - Shangri-La Colombo (Booked)" },
  { date: "2026-12-05", title: "Grand Wedding - Cinnamon Grand (Booked)" },
  { date: "2026-12-12", title: "Church Wedding & Reception (Booked)" },
  { date: "2026-12-20", title: "Pre-Shoot - Ella (Booked)" },
];

const STORAGE_KEYS = {
  BOOKINGS: 'ranas_story_booked_dates',
  ICAL_URL: 'ranas_story_google_ical_url',
  SYNC_ENABLED: 'ranas_story_google_sync_enabled',
  WHATSAPP_NUMBER: 'ranas_story_whatsapp_number',
};

// Retrieve stored or default booked dates
export const getStoredBookings = () => {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.BOOKINGS);
    if (data) {
      return JSON.parse(data);
    }
  } catch (e) {
    console.warn("Could not read localStorage", e);
  }
  return DEFAULT_BOOKED_EVENTS;
};

// Save bookings to localStorage
export const saveBookings = (bookings) => {
  try {
    localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify(bookings));
  } catch (e) {
    console.warn("Could not write to localStorage", e);
  }
};

// Check if a given date string (YYYY-MM-DD) is booked
export const isDateBooked = (dateStr, bookedList) => {
  const list = bookedList || getStoredBookings();
  return list.some(item => item.date === dateStr);
};

// Get booking title/details for a date
export const getBookingDetails = (dateStr, bookedList) => {
  const list = bookedList || getStoredBookings();
  return list.find(item => item.date === dateStr);
};

// Toggle or add a booking date manually
export const toggleDateBooking = (dateStr, title = "Booked via Google Calendar") => {
  const current = getStoredBookings();
  const exists = current.find(item => item.date === dateStr);
  let updated;
  if (exists) {
    updated = current.filter(item => item.date !== dateStr);
  } else {
    updated = [...current, { date: dateStr, title }];
  }
  saveBookings(updated);
  return updated;
};

/**
 * Basic iCal / ICS Parser
 * Parses VEVENT blocks and extracts DTSTART dates.
 */
export const parseICS = (icsText) => {
  const events = [];
  const lines = icsText.split(/\r\n|\n|\r/);
  let inEvent = false;
  let currentEvent = {};

  for (let line of lines) {
    line = line.trim();
    if (line === 'BEGIN:VEVENT') {
      inEvent = true;
      currentEvent = {};
    } else if (line === 'END:VEVENT') {
      if (currentEvent.date) {
        events.push(currentEvent);
      }
      inEvent = false;
    } else if (inEvent) {
      if (line.startsWith('DTSTART')) {
        // e.g. DTSTART;VALUE=DATE:20261120 or DTSTART:20261120T100000Z
        const val = line.split(':')[1];
        if (val && val.length >= 8) {
          const y = val.substring(0, 4);
          const m = val.substring(4, 6);
          const d = val.substring(6, 8);
          currentEvent.date = `${y}-${m}-${d}`;
        }
      } else if (line.startsWith('SUMMARY:')) {
        currentEvent.title = line.substring(8);
      }
    }
  }
  return events;
};

/**
 * Fetch and sync events from Google Calendar iCal public URL
 */
export const fetchGoogleCalendarEvents = async (icalUrl) => {
  if (!icalUrl || !icalUrl.trim()) {
    throw new Error("No Google Calendar iCal URL provided.");
  }

  // To bypass browser CORS when reading external Google Calendar .ics directly,
  // we can use a reliable public proxy or direct fetch if hosted on same domain.
  const corsProxies = [
    (url) => `https://api.allorigins.win/raw?url=${encodeURIComponent(url)}`,
    (url) => `https://corsproxy.io/?${encodeURIComponent(url)}`
  ];

  let rawIcs = null;
  let lastError = null;

  for (const makeProxy of corsProxies) {
    try {
      const response = await fetch(makeProxy(icalUrl));
      if (response.ok) {
        rawIcs = await response.text();
        if (rawIcs && rawIcs.includes('BEGIN:VCALENDAR')) {
          break;
        }
      }
    } catch (err) {
      lastError = err;
    }
  }

  if (!rawIcs || !rawIcs.includes('BEGIN:VCALENDAR')) {
    throw new Error(lastError?.message || "Failed to fetch Google Calendar feed. Ensure the calendar is set to Public.");
  }

  const parsedEvents = parseICS(rawIcs);
  return parsedEvents;
};

// Build WhatsApp click-to-chat URL with structured message
export const generateWhatsAppLink = ({
  phone,
  photographerName = "Rana",
  clientName,
  clientPhone,
  date,
  packageChoice,
  eventType,
  location,
  notes
}) => {
  const cleanPhone = phone.replace(/[^0-9]/g, '');
  
  const text = `📸 *NEW BOOKING INQUIRY - RANA'S STORY* 📸
------------------------------------
Hello ${photographerName}, I would love to check and book your photography services!

📅 *Requested Date:* ${date}
🎉 *Event / Shoot Type:* ${eventType || "Wedding / Pre-Shoot"}
💎 *Selected Package:* ${packageChoice || "Standard Package"}
📍 *Shoot Location / Venue:* ${location || "Not specified"}

👤 *Client Name:* ${clientName}
📱 *Client Phone:* ${clientPhone}
${notes ? `📝 *Special Requests / Notes:* ${notes}\n` : ''}
------------------------------------
Looking forward to capturing this special story together! ✨`;

  return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(text)}`;
};
