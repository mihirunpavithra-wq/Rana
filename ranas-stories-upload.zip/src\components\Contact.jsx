import React from 'react';
import { photographerConfig } from '../data/portfolioData';
import { Phone, Mail, MapPin, MessageCircle, Music2, Clock } from 'lucide-react';

const InstagramIcon = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect width="20" height="20" x="2" y="2" rx="5" ry="5"/>
    <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/>
    <line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/>
  </svg>
);

const FacebookIcon = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/>
  </svg>
);

export default function Contact() {
  return (
    <section id="contact" className="py-24 relative" style={{ backgroundColor: '#1e2a38' }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs uppercase tracking-widest font-semibold" style={{ color: '#89B7C2' }}>
            Get In Touch • Let's Create Magic
          </span>
          <h2 className="font-cinzel text-3xl sm:text-5xl font-bold text-white mt-3 mb-4">
            Connect With Rana
          </h2>
          <div className="w-16 h-1 mx-auto mb-6 rounded-full"
            style={{ background: 'linear-gradient(90deg, #3A6A6B, #89B7C2)' }} />
          <p className="text-sm sm:text-base font-light" style={{ color: '#9bb5bf' }}>
            Have questions or want to discuss your wedding plans? We are available 7 days a week on WhatsApp and call.
          </p>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 max-w-5xl mx-auto">

          {/* WhatsApp Card */}
          <div className="lg:col-span-7 rounded-3xl p-8 border flex flex-col justify-between shadow-2xl"
            style={{
              background: 'linear-gradient(160deg, rgba(58,106,107,0.25) 0%, rgba(42,54,80,0.9) 60%, rgba(30,42,56,1) 100%)',
              borderColor: 'rgba(73,132,150,0.35)'
            }}>
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider mb-6 border"
                style={{ backgroundColor: 'rgba(58,106,107,0.2)', borderColor: 'rgba(73,132,150,0.4)', color: '#89B7C2' }}>
                <span className="w-2 h-2 rounded-full animate-ping" style={{ backgroundColor: '#3A6A6B' }} />
                <span>Fastest Response Via WhatsApp</span>
              </div>

              <h3 className="font-cinzel text-2xl sm:text-3xl font-bold text-white mb-3">
                Chat Directly With Rana
              </h3>

              <p className="text-sm sm:text-base font-light mb-6 leading-relaxed" style={{ color: '#9bb5bf' }}>
                Send a quick greeting, request customized quotations, or confirm available dates for your wedding, engagement, or portrait session.
              </p>

              {/* Sinhala Banner */}
              <div className="p-4 rounded-xl mb-8 text-xs sm:text-sm font-medium border"
                style={{ backgroundColor: 'rgba(73,132,150,0.1)', borderColor: 'rgba(137,183,194,0.2)', color: '#89B7C2' }}>
                ඔබගේ විශේෂ දිනය වෙන්කර ගැනීමට හෝ විස්තර දැනගැනීමට WhatsApp හරහා සෘජුවම සම්බන්ධ වන්න!
              </div>
            </div>

            <a
              href={`https://wa.me/${photographerConfig.whatsappNumber}?text=Hi%20Rana,%20I'm%20reaching%20out%20from%20your%20website%20to%20discuss%20a%20photography%20shoot!`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-4 px-6 rounded-2xl text-white font-bold uppercase tracking-wider text-sm flex items-center justify-center gap-3 shadow-xl hover:scale-105 active:scale-95 transition-all"
              style={{ background: 'linear-gradient(135deg, #3A6A6B, #498496)', boxShadow: '0 10px 30px rgba(58,106,107,0.3)' }}
            >
              <MessageCircle className="w-5 h-5 fill-white" />
              <span>Start WhatsApp Conversation</span>
            </a>
          </div>

          {/* Contact Info Card */}
          <div className="lg:col-span-5 rounded-3xl p-8 border shadow-2xl flex flex-col justify-between"
            style={{ backgroundColor: '#2a3650', borderColor: 'rgba(137,183,194,0.1)' }}>
            <div>
              <h3 className="font-cinzel text-xl font-bold text-white mb-6 pb-3 border-b"
                style={{ borderColor: 'rgba(137,183,194,0.1)' }}>
                Contact Information
              </h3>

              <div className="space-y-6">
                {[
                  { icon: Phone, label: 'Phone / WhatsApp', value: photographerConfig.phoneDisplay, href: `tel:${photographerConfig.phoneDisplay}` },
                  { icon: Mail, label: 'Email Address', value: photographerConfig.email, href: `mailto:${photographerConfig.email}` },
                  { icon: MapPin, label: 'Studio Base', value: photographerConfig.location, href: null },
                  { icon: Clock, label: 'Consultation Hours', value: '9:00 AM – 8:00 PM (Everyday)', href: null },
                ].map((item, idx) => {
                  const Icon = item.icon;
                  return (
                    <div key={idx} className="flex items-start gap-3.5">
                      <div className="p-2.5 rounded-xl shrink-0" style={{ backgroundColor: 'rgba(58,106,107,0.2)', color: '#89B7C2' }}>
                        <Icon className="w-5 h-5" />
                      </div>
                      <div>
                        <span className="text-xs uppercase tracking-wider block mb-0.5" style={{ color: '#6a8fa0' }}>
                          {item.label}
                        </span>
                        {item.href ? (
                          <a href={item.href}
                            className="text-sm font-semibold text-white transition-colors"
                            onMouseEnter={e => e.currentTarget.style.color = '#89B7C2'}
                            onMouseLeave={e => e.currentTarget.style.color = 'white'}>
                            {item.value}
                          </a>
                        ) : (
                          <span className="text-sm" style={{ color: '#9bb5bf' }}>{item.value}</span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Socials */}
            <div className="pt-6 border-t mt-6" style={{ borderColor: 'rgba(137,183,194,0.1)' }}>
              <span className="text-xs uppercase tracking-wider block mb-3" style={{ color: '#6a8fa0' }}>
                Follow On Social Media:
              </span>
              <div className="flex items-center gap-3">
                {[
                  { href: photographerConfig.instagram, label: 'Instagram', Icon: InstagramIcon },
                  { href: photographerConfig.facebook, label: 'Facebook', Icon: FacebookIcon },
                  { href: photographerConfig.tiktok, label: 'TikTok', Icon: Music2 },
                ].map(({ href, label, Icon }) => (
                  <a key={label} href={href} target="_blank" rel="noopener noreferrer"
                    aria-label={label}
                    className="p-3 rounded-xl border transition-all"
                    style={{ backgroundColor: 'rgba(255,255,255,0.05)', borderColor: 'rgba(137,183,194,0.15)', color: '#9bb5bf' }}
                    onMouseEnter={e => {
                      e.currentTarget.style.backgroundColor = '#3A6A6B';
                      e.currentTarget.style.color = 'white';
                      e.currentTarget.style.borderColor = '#3A6A6B';
                    }}
                    onMouseLeave={e => {
                      e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.05)';
                      e.currentTarget.style.color = '#9bb5bf';
                      e.currentTarget.style.borderColor = 'rgba(137,183,194,0.15)';
                    }}
                  >
                    <Icon className="w-5 h-5" />
                  </a>
                ))}
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
