export const photographerConfig = {
  name: "Rana's Stories",
  tagline: "Capturing every detail of your wedding with precision and artistry",
  photographerName: "Rana",
  title: "Lead Photographer & Visual Storyteller",
  bio: "Capturing every detail of your wedding with precision and artistry, we ensure no moment is missed and your day is beautifully preserved. Based in Kelaniya, Sri Lanka, Rana's Stories has earned the trust of hundreds of couples across the island — with 100% recommendation from every client.",
  experienceYears: 5,
  weddingsCaptured: "300+",
  happyClients: "3.4K+ Followers",
  rating: "100% Recommend",
  whatsappNumber: "94770096026", // 077 009 6026 in international format
  phoneDisplay: "077 009 6026",
  email: "ranasstories@gmail.com",
  location: "Kelaniya, Sri Lanka (Available Islandwide)",
  instagram: "https://instagram.com/ranasstories",
  facebook: "https://www.facebook.com/share/1FBuRkEFy4/",
  tiktok: "https://tiktok.com/@ranasstories",
};

export const categories = [
  { id: "all", label: "All Work" },
  { id: "weddings", label: "Weddings" },
  { id: "preshoots", label: "Pre-Shoots & Couple" },
  { id: "portraits", label: "Portraits" },
  { id: "events", label: "Events & Celebrations" },
];

export const portfolioItems = [
  {
    id: 1,
    title: "The Royal Kandyan Vow",
    category: "weddings",
    location: "Earl's Regency, Kandy",
    client: "Kasun & Sanduni",
    image: "https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=1200&q=80",
    description: "Traditional Kandyan wedding filled with regal charm, golden sunrise lighting, and unforgettable emotional moments.",
    date: "2026-03-12"
  },
  {
    id: 2,
    title: "Golden Hour Ocean Romance",
    category: "preshoots",
    location: "Mirissa Beach, Sri Lanka",
    client: "Dilshan & Tharushi",
    image: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=1200&q=80",
    description: "A breezy sunset pre-shoot catching the warm coastal glow and deep intimacy between two souls.",
    date: "2026-04-05"
  },
  {
    id: 3,
    title: "Whimsical Forest Engagement",
    category: "preshoots",
    location: "Hanthana Mountain Range",
    client: "Nuwan & Chathurika",
    image: "https://images.unsplash.com/photo-1537633552985-df8429e8048b?auto=format&fit=crop&w=1200&q=80",
    description: "Moody, mist-covered mountain shots creating a dreamy fairytale aesthetic.",
    date: "2026-02-18"
  },
  {
    id: 4,
    title: "Modern Minimalist Church Wedding",
    category: "weddings",
    location: "St. Mary's, Negombo",
    client: "Kevin & Michelle",
    image: "https://images.unsplash.com/photo-1519228905881-b55239e0f639?auto=format&fit=crop&w=1200&q=80",
    description: "Pure elegance, monochrome architectural framing, and tearful vow exchanges.",
    date: "2026-01-24"
  },
  {
    id: 5,
    title: "Soulful Cultural Portrait",
    category: "portraits",
    location: "Colombo Studio",
    client: "Amaya",
    image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1200&q=80",
    description: "High-contrast studio lighting highlighting authentic facial expressions and grace.",
    date: "2026-03-29"
  },
  {
    id: 6,
    title: "Lakeside Sunset Homecoming",
    category: "weddings",
    location: "Cinnamon Citadel, Kandy",
    client: "Sahan & Rashmi",
    image: "https://images.unsplash.com/photo-1583939003579-730e3918a45a?auto=format&fit=crop&w=1200&q=80",
    description: "A breathtaking lakeside dinner under twinkling fairy lights and joyful dance celebrations.",
    date: "2026-05-14"
  },
  {
    id: 7,
    title: "Editorial Fashion Story",
    category: "portraits",
    location: "Galle Fort Old Streets",
    client: "Shenali",
    image: "https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=1200&q=80",
    description: "Vintage Dutch architecture paired with contemporary Sri Lankan haute couture styling.",
    date: "2026-06-02"
  },
  {
    id: 8,
    title: "Vibrant Sangeet & Music Night",
    category: "events",
    location: "Shangri-La, Colombo",
    client: "The Mehtas",
    image: "https://images.unsplash.com/photo-1465847899084-d164df4dedc6?auto=format&fit=crop&w=1200&q=80",
    description: "High energy, candid festival moments, colorful traditional attires, and sparkler night.",
    date: "2026-07-19"
  },
  {
    id: 9,
    title: "Intimate Garden Vows",
    category: "weddings",
    location: "Nuwara Eliya Hilltop",
    client: "Lahiru & Nipuni",
    image: "https://images.unsplash.com/photo-1520854221256-17451cc331bf?auto=format&fit=crop&w=1200&q=80",
    description: "Surrounded by tea plantations and pine trees, a warm celebration with 50 closest family members.",
    date: "2026-08-10"
  }
];

export const packages = [
  {
    id: "preshoot",
    name: "Pre-Shoot & Couple Story",
    subtitle: "Perfect for Save-The-Dates & Engagements",
    price: "LKR 65,000",
    popular: false,
    features: [
      "Up to 4 Hours of shoot time",
      "2 Selected scenic locations",
      "50 Retouched High-Res Digital Photos",
      "Online Private Gallery (1-Year Access)",
      "1 Framed 12x18 Enlargement Print",
      "Full printing & sharing rights"
    ]
  },
  {
    id: "wedding-signature",
    name: "Signature Wedding Story",
    subtitle: "The Complete Wedding Day Coverage",
    price: "LKR 185,000",
    popular: true,
    features: [
      "Full Day Coverage (Dressing, Ceremony & Reception)",
      "2 Senior Photographers (Rana + Associate)",
      "Unlimited Photos Captured & Color Graded",
      "120 Fine-Art Retouched Images",
      "Luxury Magazine Album (30 Sheets / 60 Pages)",
      "2 Mini Parents Albums (8x10)",
      "Full-Resolution USB drive in customized wooden box",
      "Same-day preview highlights for social media"
    ]
  },
  {
    id: "luxury-combo",
    name: "Grand Wedding + Homecoming",
    subtitle: "Ultimate Two-Day Masterpiece",
    price: "LKR 295,000",
    popular: false,
    features: [
      "Both Wedding Day & Homecoming Ceremony",
      "Complimentary Sunset Pre-Shoot Session",
      "3 Photographers + Drone Aerial Coverage",
      "2 Premium Leather-Bound Wedding Albums",
      "4 Parent Gift Albums",
      "3 Large Canvas Wall Arts (16x24)",
      "All edited photos delivered in high-speed cloud gallery",
      "Priority editing & delivery within 2 weeks"
    ]
  }
];

export const testimonials = [
  {
    id: 1,
    couple: "Kasun & Sanduni",
    event: "Wedding at Earl's Regency",
    review: "Rana didn't just take photos; he captured the soul of our wedding day! Looking back at our album makes us cry happy tears every single time. Booking him was the best decision we made!",
    rating: 5,
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80"
  },
  {
    id: 2,
    couple: "Dilshan & Tharushi",
    event: "Mirissa Sunset Pre-Shoot",
    review: "We are both very camera-shy, but Rana made us feel so relaxed and comfortable. The photos look like stills straight out of a romantic movie!",
    rating: 5,
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80"
  },
  {
    id: 3,
    couple: "Kevin & Michelle",
    event: "St. Mary's Wedding Ceremony",
    review: "Super professional, timely, and responsive on WhatsApp. The calendar on his website was accurate, and the WhatsApp booking process was totally hassle-free!",
    rating: 5,
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80"
  }
];
