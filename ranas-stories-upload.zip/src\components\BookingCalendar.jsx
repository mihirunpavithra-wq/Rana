import React, { useState, useEffect } from 'react';
import { 
  Calendar as CalendarIcon, 
  ChevronLeft, 
  ChevronRight, 
  CheckCircle, 
  XCircle, 
  RefreshCw, 
  Settings, 
  Send, 
  MessageCircle, 
  Clock, 
  AlertCircle, 
  Check, 
  Sparkles,
  Info
} from 'lucide-react';
import { 
  getStoredBookings, 
  saveBookings, 
  isDateBooked, 
  getBookingDetails, 
  toggleDateBooking,
  fetchGoogleCalendarEvents,
  generateWhatsAppLink,
  formatDateKey 
} from '../services/calendarService';
import { photographerConfig, packages } from '../data/portfolioData';

export default function BookingCalendar({ preselectedPackage }) {
  // Calendar View State
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDateStr, setSelectedDateStr] = useState('');
  const [bookedDates, setBookedDates] = useState([]);
  
  // Google Calendar Sync State
  const [icalUrl, setIcalUrl] = useState(() => localStorage.getItem('ranas_story_google_ical_url') || '');
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStatus, setSyncStatus] = useState({ success: true, message: 'Google Calendar sync ready' });
  const [showSettingsModal, setShowSettingsModal] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [adminMode, setAdminMode] = useState(false);

  // Booking Form State
  const [formData, setFormData] = useState({
    clientName: '',
    clientPhone: '',
    packageChoice: preselectedPackage || packages[1].name,
    eventType: 'Wedding Photography',
    location: '',
    notes: '',
  });

  // Keep package updated if selected from packages section
  useEffect(() => {
    if (preselectedPackage) {
      setFormData(prev => ({ ...prev, packageChoice: preselectedPackage }));
    }
  }, [preselectedPackage]);

  // Load booked dates on mount
  useEffect(() => {
    const stored = getStoredBookings();
    setBookedDates(stored);

    // Auto-sync if iCal URL is configured
    if (icalUrl) {
      handleSyncGoogleCalendar(icalUrl);
    }
  }, []);

  // Handle manual Google Calendar Sync
  const handleSyncGoogleCalendar = async (urlToSync = icalUrl) => {
    if (!urlToSync.trim()) {
      setSyncStatus({ success: false, message: 'Please enter a valid Google Calendar iCal link' });
      return;
    }

    setIsSyncing(true);
    setSyncStatus({ success: true, message: 'Syncing with Google Calendar...' });

    try {
      const fetchedEvents = await fetchGoogleCalendarEvents(urlToSync);
      if (fetchedEvents && fetchedEvents.length > 0) {
        // Merge with existing manual bookings
        const current = getStoredBookings();
        const mergedMap = new Map();
        
        current.forEach(item => mergedMap.set(item.date, item));
        fetchedEvents.forEach(item => {
          mergedMap.set(item.date, { date: item.date, title: item.title || 'Booked on Google Calendar' });
        });

        const mergedList = Array.from(mergedMap.values());
        saveBookings(mergedList);
        setBookedDates(mergedList);
        localStorage.setItem('ranas_story_google_ical_url', urlToSync);

        setSyncStatus({ 
          success: true, 
          message: `Successfully synced ${fetchedEvents.length} events from Google Calendar!` 
        });
      } else {
        setSyncStatus({ 
          success: true, 
          message: 'Calendar connected. No upcoming events found.' 
        });
      }
    } catch (err) {
      console.error(err);
      setSyncStatus({ 
        success: false, 
        message: 'Could not fetch Google Calendar. Verify the calendar is public or use manual date toggles below.' 
      });
    } finally {
      setIsSyncing(false);
    }
  };

  // Month navigation
  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  const prevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };

  const resetToToday = () => {
    setCurrentDate(new Date());
  };

  // Build calendar matrix
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const firstDayOfMonth = new Date(year, month, 1).getDay(); // 0 is Sunday
  const daysInMonth = new Date(year, month + 1, 0).getDate();

  // Create empty slots for days before 1st of month
  const calendarCells = [];
  for (let i = 0; i < firstDayOfMonth; i++) {
    calendarCells.push(null);
  }
  for (let day = 1; day <= daysInMonth; day++) {
    calendarCells.push(new Date(year, month, day));
  }

  // Handle clicking a day
  const handleDateClick = (dateObj) => {
    if (!dateObj) return;
    const dateKey = formatDateKey(dateObj);
    const booked = isDateBooked(dateKey, bookedDates);

    if (adminMode) {
      // Toggle booking in Admin Mode
      const updated = toggleDateBooking(dateKey, 'Manual Booking (Rana)');
      setBookedDates(updated);
      return;
    }

    if (booked) {
      // Cannot select booked date
      return;
    }

    setSelectedDateStr(dateKey);
  };

  // Form field change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  // WhatsApp submit
  const handleWhatsAppBooking = (e) => {
    e.preventDefault();
    if (!selectedDateStr) {
      alert("Please choose an available date on the calendar first!");
      return;
    }
    if (!formData.clientName || !formData.clientPhone) {
      alert("Please provide your Name and WhatsApp phone number.");
      return;
    }

    const waUrl = generateWhatsAppLink({
      phone: photographerConfig.whatsappNumber,
      photographerName: photographerConfig.photographerName,
      clientName: formData.clientName,
      clientPhone: formData.clientPhone,
      date: selectedDateStr,
      packageChoice: formData.packageChoice,
      eventType: formData.eventType,
      location: formData.location,
      notes: formData.notes,
    });

    // Open WhatsApp
    window.open(waUrl, '_blank');
    setShowSuccessModal(true);
  };

  const todayStr = formatDateKey(new Date());

  return (
    <section id="calendar" className="py-24 bg-[#090a0f] relative">
      {/* Background radial glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-amber-500/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold tracking-wider uppercase mb-4">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span>Live Availability & Google Calendar Sync</span>
          </div>

          <h2 className="font-cinzel text-3xl sm:text-5xl font-bold text-white mb-4">
            Check Dates & Book on WhatsApp
          </h2>
          <div className="w-16 h-1 bg-gradient-to-r from-amber-500 to-yellow-300 mx-auto mb-6" />
          
          <p className="text-slate-300 text-sm sm:text-base font-light leading-relaxed">
            Select an open date from the calendar below. Dates booked on Rana's Google Calendar automatically reflect here as <span className="text-rose-400 font-semibold">BOOKED</span>.
          </p>
        </div>

        {/* Sync Status Banner & Admin Controls */}
        <div className="max-w-5xl mx-auto mb-8 p-3.5 rounded-2xl bg-white/[0.03] border border-white/10 flex flex-wrap items-center justify-between gap-4 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <div className="w-3 h-3 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs sm:text-sm text-slate-300">
              <strong className="text-white">Status:</strong> {syncStatus.message}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleSyncGoogleCalendar()}
              disabled={isSyncing}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-slate-200 bg-white/5 hover:bg-white/10 border border-white/10 transition-colors disabled:opacity-50"
              title="Refresh Google Calendar sync"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin text-amber-400' : ''}`} />
              <span>{isSyncing ? 'Syncing...' : 'Sync Calendar'}</span>
            </button>

            <button
              onClick={() => setShowSettingsModal(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-amber-300 bg-amber-400/10 hover:bg-amber-400/20 border border-amber-400/30 transition-colors"
            >
              <Settings className="w-3.5 h-3.5" />
              <span>Google Calendar Settings</span>
            </button>
          </div>
        </div>

        {/* Calendar and Form Two-Column Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 max-w-6xl mx-auto">
          
          {/* Left Column: Interactive Calendar (7 Cols) */}
          <div className="lg:col-span-7 bg-[#0d0e17] rounded-3xl p-6 sm:p-8 border border-white/10 shadow-2xl">
            
            {/* Calendar Controls (Month, Year, Prev, Next) */}
            <div className="flex items-center justify-between mb-6 pb-4 border-b border-white/10">
              <div>
                <h3 className="font-cinzel text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
                  <span>{monthNames[month]} {year}</span>
                </h3>
                <span className="text-xs text-slate-400 font-light">
                  Click on an available date to reserve
                </span>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={resetToToday}
                  className="px-2.5 py-1 rounded-md text-[11px] font-semibold uppercase tracking-wider text-slate-300 bg-white/5 hover:bg-white/10 border border-white/10 mr-1"
                >
                  Today
                </button>
                <button
                  onClick={prevMonth}
                  className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors border border-white/10"
                  aria-label="Previous Month"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={nextMonth}
                  className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors border border-white/10"
                  aria-label="Next Month"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Days of week header */}
            <div className="grid grid-cols-7 gap-1 sm:gap-2 text-center mb-3">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
                <div key={day} className="text-[11px] font-bold uppercase tracking-wider text-slate-400 py-1">
                  {day}
                </div>
              ))}
            </div>

            {/* Calendar Grid Days */}
            <div className="grid grid-cols-7 gap-1 sm:gap-2">
              {calendarCells.map((dateObj, idx) => {
                if (!dateObj) {
                  return <div key={`empty-${idx}`} className="h-16 sm:h-20 rounded-xl bg-transparent" />;
                }

                const dateKey = formatDateKey(dateObj);
                const booked = isDateBooked(dateKey, bookedDates);
                const isSelected = selectedDateStr === dateKey;
                const isToday = dateKey === todayStr;
                const isPast = dateKey < todayStr;
                const details = booked ? getBookingDetails(dateKey, bookedDates) : null;

                return (
                  <button
                    key={dateKey}
                    onClick={() => handleDateClick(dateObj)}
                    disabled={isPast || (booked && !adminMode)}
                    className={`h-16 sm:h-20 p-1 sm:p-2 rounded-xl flex flex-col justify-between items-center transition-all relative group text-left ${
                      isPast
                        ? 'opacity-30 cursor-not-allowed bg-black/20 border border-white/5'
                        : booked
                        ? 'bg-rose-950/30 border border-rose-500/40 text-rose-200 cursor-not-allowed'
                        : isSelected
                        ? 'bg-gradient-to-b from-amber-400 to-amber-500 text-black font-bold shadow-lg shadow-amber-500/30 scale-105 z-10'
                        : 'bg-white/[0.02] hover:bg-white/[0.08] text-slate-200 border border-white/5 hover:border-amber-400/40 cursor-pointer'
                    }`}
                  >
                    {/* Top Row: Date Number & Badge */}
                    <div className="w-full flex items-center justify-between">
                      <span className={`text-xs sm:text-sm font-semibold ${isSelected ? 'text-black' : isToday ? 'text-amber-400' : 'text-slate-200'}`}>
                        {dateObj.getDate()}
                      </span>

                      {isToday && !isSelected && (
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-400" title="Today" />
                      )}
                    </div>

                    {/* Bottom Status label */}
                    <div className="w-full text-center">
                      {booked ? (
                        <div className="inline-flex items-center gap-0.5 px-1 py-0.5 rounded bg-rose-500/20 text-rose-300 text-[9px] sm:text-[10px] font-bold uppercase tracking-wider w-full justify-center">
                          <XCircle className="w-2.5 h-2.5 shrink-0" />
                          <span className="truncate">Booked</span>
                        </div>
                      ) : isSelected ? (
                        <div className="inline-flex items-center gap-0.5 text-black text-[9px] sm:text-[10px] font-bold uppercase tracking-wider">
                          <Check className="w-3 h-3 stroke-[3]" />
                          <span>Selected</span>
                        </div>
                      ) : (
                        <div className="hidden sm:inline-block text-[9px] text-emerald-400/80 font-medium group-hover:text-amber-300 transition-colors">
                          Available
                        </div>
                      )}
                    </div>

                    {/* Tooltip on hover for booked events */}
                    {booked && details && (
                      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 hidden group-hover:block z-30 w-36 p-2 rounded-lg bg-black/90 text-[10px] text-white border border-rose-500/40 pointer-events-none text-center shadow-xl">
                        🔒 {details.title || 'Reserved on Google Calendar'}
                      </div>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Calendar Legend */}
            <div className="mt-6 pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-4 text-xs">
              <div className="flex items-center gap-5">
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded bg-white/10 border border-white/20" />
                  <span className="text-slate-400">Available Date</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded bg-rose-950/60 border border-rose-500/60" />
                  <span className="text-rose-400 font-medium">Booked (Google Calendar)</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-3 h-3 rounded bg-amber-400" />
                  <span className="text-amber-300 font-medium">Selected</span>
                </div>
              </div>

              {/* Admin Mode Toggle */}
              <button
                onClick={() => setAdminMode(!adminMode)}
                className={`text-[11px] font-semibold px-2.5 py-1 rounded-md border transition-colors ${
                  adminMode 
                    ? 'bg-amber-400 text-black border-amber-300' 
                    : 'text-slate-400 border-white/10 hover:text-white'
                }`}
              >
                {adminMode ? '⚡ Admin Mode: ON (Click to toggle bookings)' : 'Admin Mode'}
              </button>
            </div>

          </div>

          {/* Right Column: WhatsApp Booking Form (5 Cols) */}
          <div className="lg:col-span-5 bg-[#0d0e17] rounded-3xl p-6 sm:p-8 border border-white/10 shadow-2xl flex flex-col justify-between">
            <div>
              {/* Selected Date Header */}
              <div className="mb-6 pb-4 border-b border-white/10">
                <span className="text-xs uppercase tracking-wider text-amber-400 font-semibold block mb-1">
                  Step 2: Reserve via WhatsApp
                </span>
                <h3 className="font-cinzel text-xl font-bold text-white flex items-center gap-2">
                  <MessageCircle className="w-5 h-5 text-emerald-400" />
                  <span>Send Booking Inquiry</span>
                </h3>
                
                {selectedDateStr ? (
                  <div className="mt-3 p-3 rounded-xl bg-amber-400/10 border border-amber-400/30 flex items-center justify-between">
                    <div>
                      <div className="text-[11px] uppercase tracking-wider text-amber-300 font-semibold">
                        Selected Shoot Date:
                      </div>
                      <div className="text-lg font-bold text-white font-serif-display">
                        {selectedDateStr}
                      </div>
                    </div>
                    <CheckCircle className="w-5 h-5 text-amber-400" />
                  </div>
                ) : (
                  <div className="mt-3 p-3 rounded-xl bg-white/5 border border-white/10 flex items-center gap-2 text-xs text-slate-300">
                    <Info className="w-4 h-4 text-amber-400 shrink-0" />
                    <span>Please tap an available date on the calendar to select it.</span>
                  </div>
                )}
              </div>

              {/* Form inputs */}
              <form onSubmit={handleWhatsAppBooking} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
                    Your Full Name *
                  </label>
                  <input
                    type="text"
                    name="clientName"
                    required
                    value={formData.clientName}
                    onChange={handleInputChange}
                    placeholder="e.g. Kasun Perera & Sanduni"
                    className="w-full px-4 py-2.5 rounded-xl bg-white/5 border border-white/10 focus:border-amber-400 focus:outline-none text-white text-sm placeholder:text-slate-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
                    WhatsApp Phone Number *
                  </label>
                  <input
                    type="tel"
                    name="clientPhone"
                    required
                    value={formData.clientPhone}
                    onChange={handleInputChange}
                    placeholder="e.g. 077 009 6026"
                    className="w-full px-4 py-2.5 rounded-xl bg-white/5 border border-white/10 focus:border-amber-400 focus:outline-none text-white text-sm placeholder:text-slate-500"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
                      Event Type
                    </label>
                    <select
                      name="eventType"
                      value={formData.eventType}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2.5 rounded-xl bg-[#141622] border border-white/10 focus:border-amber-400 focus:outline-none text-white text-xs"
                    >
                      <option value="Wedding Photography">Wedding Ceremony</option>
                      <option value="Homecoming Reception">Homecoming</option>
                      <option value="Pre-Shoot & Couple Story">Pre-Shoot / Engagement</option>
                      <option value="Portrait Session">Portrait Session</option>
                      <option value="Birthday / Event Coverage">Event / Party</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
                      Package
                    </label>
                    <select
                      name="packageChoice"
                      value={formData.packageChoice}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2.5 rounded-xl bg-[#141622] border border-white/10 focus:border-amber-400 focus:outline-none text-white text-xs"
                    >
                      {packages.map(p => (
                        <option key={p.id} value={p.name}>{p.name}</option>
                      ))}
                      <option value="Custom Photography Quote">Custom Quote</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
                    Shoot Location / Venue
                  </label>
                  <input
                    type="text"
                    name="location"
                    value={formData.location}
                    onChange={handleInputChange}
                    placeholder="e.g. Earl's Regency Kandy / Colombo"
                    className="w-full px-4 py-2.5 rounded-xl bg-white/5 border border-white/10 focus:border-amber-400 focus:outline-none text-white text-sm placeholder:text-slate-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
                    Special Notes / Timing
                  </label>
                  <textarea
                    name="notes"
                    rows="2"
                    value={formData.notes}
                    onChange={handleInputChange}
                    placeholder="e.g. Poruwa ceremony at 8:30 AM, outdoor photo session needed."
                    className="w-full px-4 py-2 rounded-xl bg-white/5 border border-white/10 focus:border-amber-400 focus:outline-none text-white text-xs placeholder:text-slate-500 resize-none"
                  />
                </div>

                {/* Submit to WhatsApp */}
                <button
                  type="submit"
                  disabled={!selectedDateStr}
                  className={`w-full py-4 px-6 rounded-2xl font-bold uppercase tracking-wider text-xs sm:text-sm flex items-center justify-center gap-2.5 transition-all shadow-xl ${
                    selectedDateStr
                      ? 'bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-400 hover:to-green-500 text-white shadow-emerald-900/40 hover:scale-[1.02] active:scale-[0.98]'
                      : 'bg-white/10 text-slate-400 cursor-not-allowed border border-white/10'
                  }`}
                >
                  <MessageCircle className="w-5 h-5 fill-white" />
                  <span>Confirm & Book via WhatsApp</span>
                </button>
              </form>
            </div>

            <div className="mt-6 pt-4 border-t border-white/10 text-[11px] text-slate-400 flex items-center justify-between">
              <span>Direct WhatsApp: {photographerConfig.phoneDisplay}</span>
              <span className="text-amber-400">Instant Response Guaranteed</span>
            </div>
          </div>

        </div>

      </div>

      {/* Google Calendar Settings Modal */}
      {showSettingsModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#10121d] border border-white/20 rounded-3xl p-6 sm:p-8 max-w-xl w-full shadow-2xl relative animate-in zoom-in-95 duration-200">
            <h3 className="font-cinzel text-xl sm:text-2xl font-bold text-white mb-2 flex items-center gap-2">
              <Settings className="w-5 h-5 text-amber-400" />
              <span>Google Calendar Sync Settings</span>
            </h3>
            
            <p className="text-xs sm:text-sm text-slate-300 mb-6">
              Connect your Google Calendar so any booking you add on your phone or computer automatically shows as <strong>BOOKED</strong> on the website.
            </p>

            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1">
                  Google Calendar iCal Public URL (.ics)
                </label>
                <input
                  type="url"
                  value={icalUrl}
                  onChange={(e) => setIcalUrl(e.target.value)}
                  placeholder="https://calendar.google.com/calendar/ical/.../public/basic.ics"
                  className="w-full px-4 py-2.5 rounded-xl bg-white/5 border border-white/20 focus:border-amber-400 focus:outline-none text-white text-xs"
                />
              </div>

              {/* Step by step guide */}
              <div className="p-4 rounded-xl bg-white/[0.03] border border-white/10 text-xs text-slate-300 space-y-2">
                <div className="font-semibold text-amber-300 flex items-center gap-1.5">
                  <Info className="w-3.5 h-3.5" />
                  <span>How to get your Google Calendar Link:</span>
                </div>
                <ol className="list-decimal pl-4 space-y-1 text-slate-300">
                  <li>Open <strong>calendar.google.com</strong> on your computer.</li>
                  <li>Click on the 3 dots next to your photography calendar &gt; <strong>Settings and sharing</strong>.</li>
                  <li>Under <em>Access permissions</em>, check <strong>"Make available to public"</strong>.</li>
                  <li>Scroll down to <strong>"Public address in iCal format"</strong>, copy the link, and paste it here!</li>
                </ol>
              </div>

              {/* Quick Preset / Demo Buttons */}
              <div>
                <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-400 block mb-2">
                  Quick Actions:
                </span>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => {
                      const sample = [
                        { date: '2026-10-24', title: 'Kasun Wedding (Kandy)' },
                        { date: '2026-11-07', title: 'Galle Face Hotel Shoot' },
                        { date: '2026-11-21', title: 'Nuwara Eliya Destination' },
                        { date: '2026-12-05', title: 'Cinnamon Grand Ballroom' },
                      ];
                      saveBookings(sample);
                      setBookedDates(sample);
                      alert('Loaded wedding season sample bookings!');
                    }}
                    className="px-3 py-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white text-xs"
                  >
                    Load Sample Bookings
                  </button>

                  <button
                    onClick={() => {
                      saveBookings([]);
                      setBookedDates([]);
                      alert('Cleared all booked dates.');
                    }}
                    className="px-3 py-1.5 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 text-xs"
                  >
                    Clear All Bookings
                  </button>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-4 border-t border-white/10">
              <button
                onClick={() => setShowSettingsModal(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white"
              >
                Close
              </button>

              <button
                onClick={() => {
                  handleSyncGoogleCalendar(icalUrl);
                  setShowSettingsModal(false);
                }}
                className="px-5 py-2 rounded-xl text-xs font-bold uppercase tracking-wider bg-amber-400 hover:bg-amber-300 text-black shadow-lg"
              >
                Save & Sync Now
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Success Modal after WhatsApp launch */}
      {showSuccessModal && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#10121d] border border-emerald-500/30 rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl text-center relative animate-in zoom-in-95 duration-200">
            <div className="w-14 h-14 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center mb-4">
              <CheckCircle className="w-8 h-8" />
            </div>

            <h3 className="font-cinzel text-2xl font-bold text-white mb-2">
              WhatsApp Inquiry Prepared!
            </h3>
            
            <p className="text-sm text-slate-300 mb-6 leading-relaxed">
              Your inquiry for <strong>{selectedDateStr}</strong> has been created. Send the message on WhatsApp to finalize your booking directly with Rana.
            </p>

            <div className="p-4 rounded-xl bg-white/[0.04] border border-white/10 text-left text-xs text-slate-300 space-y-2 mb-6">
              <div className="font-semibold text-amber-300">What happens next?</div>
              <div className="flex items-start gap-2">
                <span className="w-4 h-4 rounded-full bg-amber-400/20 text-amber-300 flex items-center justify-center shrink-0 mt-0.5">1</span>
                <span>Rana reviews your date & confirms details on WhatsApp.</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="w-4 h-4 rounded-full bg-amber-400/20 text-amber-300 flex items-center justify-center shrink-0 mt-0.5">2</span>
                <span>Rana records it in his Google Calendar.</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="w-4 h-4 rounded-full bg-amber-400/20 text-amber-300 flex items-center justify-center shrink-0 mt-0.5">3</span>
                <span>The date is officially locked as <strong>BOOKED</strong> on this website!</span>
              </div>
            </div>

            <button
              onClick={() => setShowSuccessModal(false)}
              className="w-full py-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-black text-xs font-bold uppercase tracking-wider"
            >
              Done & Return to Website
            </button>
          </div>
        </div>
      )}

    </section>
  );
}
