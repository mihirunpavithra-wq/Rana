import React from 'react';
import { Camera, Heart, ArrowUp } from 'lucide-react';
import { photographerConfig } from '../data/portfolioData';

export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#06070a] text-slate-400 py-12 border-t border-white/10 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-8 border-b border-white/5">
          
          {/* Logo & Tagline */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-amber-600 via-amber-400 to-yellow-200 p-[1.5px]">
              <div className="w-full h-full bg-[#0d0e15] rounded-full flex items-center justify-center">
                <Camera className="w-5 h-5 text-amber-400" />
              </div>
            </div>
            <div>
              <span className="font-cinzel text-xl font-bold tracking-wider text-white">
                Rana's Story
              </span>
              <p className="text-xs text-slate-400">
                {photographerConfig.tagline}
              </p>
            </div>
          </div>

          {/* Quick Nav */}
          <div className="flex flex-wrap items-center justify-center gap-6 text-xs uppercase tracking-wider">
            <a href="#home" className="hover:text-amber-400 transition-colors">Home</a>
            <a href="#portfolio" className="hover:text-amber-400 transition-colors">Portfolio</a>
            <a href="#about" className="hover:text-amber-400 transition-colors">About</a>
            <a href="#packages" className="hover:text-amber-400 transition-colors">Packages</a>
            <a href="#calendar" className="hover:text-amber-400 transition-colors">Calendar</a>
            <a href="#contact" className="hover:text-amber-400 transition-colors">Contact</a>
          </div>

          {/* Back to top */}
          <button
            onClick={scrollToTop}
            className="p-3 rounded-full bg-white/5 hover:bg-amber-400 hover:text-black text-slate-300 transition-all border border-white/10"
            title="Back to Top"
            aria-label="Scroll to top"
          >
            <ArrowUp className="w-4 h-4" />
          </button>
        </div>

        {/* Bottom copyright */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 text-center sm:text-left">
          <p>© {new Date().getFullYear()} Rana's Story Photography. All Rights Reserved.</p>
          <p className="flex items-center justify-center gap-1">
            Crafted for weddings, portraits & celebrations across Sri Lanka.
          </p>
        </div>
      </div>
    </footer>
  );
}
