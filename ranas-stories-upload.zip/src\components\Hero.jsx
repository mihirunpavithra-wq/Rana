import React from 'react';
import { Calendar, ChevronDown, Sparkles, CheckCircle2 } from 'lucide-react';
import { photographerConfig } from '../data/portfolioData';

export default function Hero() {
  return (
    <section id="home" className="relative min-h-[92vh] flex items-center justify-center overflow-hidden pt-20"
      style={{ backgroundColor: '#1e2a38' }}>
      {/* Background Image with Cinematic Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=2000&q=85"
          alt="Cinematic Wedding Photography by Rana"
          className="w-full h-full object-cover object-center"
          style={{ filter: 'brightness(0.35)' }}
        />
        {/* Twilight + Eucalypt gradient overlay */}
        <div className="absolute inset-0"
          style={{ background: 'linear-gradient(to top, #1e2a38 0%, rgba(56,68,102,0.7) 40%, rgba(58,106,107,0.3) 80%, transparent 100%)' }} />
        <div className="absolute inset-0"
          style={{ background: 'radial-gradient(ellipse at center, transparent 0%, rgba(30,42,56,0.85) 100%)' }} />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-8">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-xs sm:text-sm font-medium tracking-wide mb-6 backdrop-blur-md border"
          style={{ backgroundColor: 'rgba(73,132,150,0.15)', borderColor: 'rgba(137,183,194,0.3)', color: '#89B7C2' }}>
          <Sparkles className="w-3.5 h-3.5" style={{ color: '#89B7C2' }} />
          <span>Cinematic Wedding & Portrait Photography • Sri Lanka</span>
        </div>

        {/* Main Title */}
        <h1 className="font-cinzel text-4xl sm:text-6xl md:text-7xl font-bold tracking-tight text-white mb-6 leading-tight">
          Where Every Frame Tells <br className="hidden sm:inline" />
          <span className="text-gradient-sky">
            Your True Story
          </span>
        </h1>

        {/* Subtitle */}
        <p className="max-w-2xl mx-auto text-base sm:text-lg font-light leading-relaxed mb-10" style={{ color: '#9bb5bf' }}>
          Timeless, emotional wedding photography and intimate couple portraits.
          Check real-time availability synced with Google Calendar and reserve your special date directly on WhatsApp.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
          <a
            href="#calendar"
            className="w-full sm:w-auto px-8 py-4 rounded-full text-white font-semibold tracking-wide text-sm uppercase shadow-xl hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2 group"
            style={{ background: 'linear-gradient(135deg, #3A6A6B, #498496)', boxShadow: '0 10px 30px rgba(73,132,150,0.3)' }}
          >
            <Calendar className="w-4 h-4 group-hover:rotate-6 transition-transform" />
            <span>Check Available Dates & Book</span>
          </a>

          <a
            href="#portfolio"
            className="w-full sm:w-auto px-8 py-4 rounded-full font-semibold tracking-wide text-sm uppercase backdrop-blur-md transition-all flex items-center justify-center gap-2 border text-white"
            style={{ backgroundColor: 'rgba(255,255,255,0.08)', borderColor: 'rgba(255,255,255,0.2)' }}
            onMouseEnter={e => e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.15)'}
            onMouseLeave={e => e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.08)'}
          >
            <span>Explore Past Work</span>
          </a>
        </div>

        {/* Stats Bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto pt-8 border-t border-white/10">
          {[
            { value: photographerConfig.weddingsCaptured, label: 'Weddings Captured' },
            { value: `${photographerConfig.experienceYears}+ Years`, label: 'Industry Experience' },
            { value: photographerConfig.happyClients, label: 'Happy Couples' },
            { value: '100%', label: 'WhatsApp Booking' },
          ].map((stat, i) => (
            <div key={i} className="p-3 text-center">
              <div className="font-cinzel text-2xl sm:text-3xl font-bold" style={{ color: '#89B7C2' }}>
                {stat.value}
              </div>
              <div className="text-xs uppercase tracking-wider mt-1" style={{ color: '#6a8fa0' }}>
                {stat.label}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll Down Arrow */}
      <a
        href="#portfolio"
        className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10 animate-bounce transition-colors"
        style={{ color: '#498496' }}
        onMouseEnter={e => e.currentTarget.style.color = '#89B7C2'}
        onMouseLeave={e => e.currentTarget.style.color = '#498496'}
        aria-label="Scroll down"
      >
        <ChevronDown className="w-6 h-6" />
      </a>
    </section>
  );
}
