import React from 'react';
import { packages, photographerConfig } from '../data/portfolioData';
import { Check, MessageCircle, ArrowRight } from 'lucide-react';

export default function Packages({ onSelectPackage }) {
  return (
    <section id="packages" className="py-24 relative" style={{ backgroundColor: '#243044' }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="text-xs uppercase tracking-widest font-semibold" style={{ color: '#89B7C2' }}>
            Investment & Collections
          </span>
          <h2 className="font-cinzel text-3xl sm:text-5xl font-bold text-white mt-3 mb-4">
            Tailored Photography Packages
          </h2>
          <div className="w-16 h-1 mx-auto mb-6 rounded-full"
            style={{ background: 'linear-gradient(90deg, #3A6A6B, #89B7C2)' }} />
          <p className="text-sm sm:text-base font-light leading-relaxed" style={{ color: '#9bb5bf' }}>
            Transparent pricing with no hidden charges. Every package can be customized to match your wedding itinerary.
          </p>
        </div>

        {/* Package Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch">
          {packages.map((pkg) => (
            <div
              key={pkg.id}
              className="relative rounded-3xl p-8 flex flex-col justify-between transition-all duration-300 border"
              style={
                pkg.popular
                  ? {
                      background: 'linear-gradient(160deg, rgba(90,60,98,0.25) 0%, rgba(42,54,80,0.9) 50%, rgba(30,42,56,1) 100%)',
                      borderColor: '#5A3C62',
                      boxShadow: '0 20px 60px rgba(90,60,98,0.2)',
                      transform: 'translateY(-8px)'
                    }
                  : {
                      backgroundColor: 'rgba(255,255,255,0.03)',
                      borderColor: 'rgba(137,183,194,0.1)'
                    }
              }
            >
              {pkg.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full text-white text-xs font-bold uppercase tracking-wider shadow-md"
                  style={{ background: 'linear-gradient(135deg, #5A3C62, #7a4d85)' }}>
                  Most Popular Choice
                </div>
              )}

              <div>
                <h3 className="font-cinzel text-2xl font-bold text-white mb-1">{pkg.name}</h3>
                <p className="text-xs font-light mb-6" style={{ color: '#7a9faf' }}>{pkg.subtitle}</p>

                <div className="mb-8">
                  <div className="text-3xl sm:text-4xl font-extrabold font-serif-display"
                    style={{ color: pkg.popular ? '#89B7C2' : '#498496' }}>
                    {pkg.price}
                  </div>
                  <span className="text-xs uppercase tracking-wider" style={{ color: '#6a8fa0' }}>
                    Full Coverage & Deliverables Included
                  </span>
                </div>

                <div className="w-full h-px mb-6" style={{ backgroundColor: 'rgba(137,183,194,0.1)' }} />

                <div className="space-y-3 mb-8">
                  <div className="text-xs font-semibold uppercase tracking-wider mb-2" style={{ color: '#9bb5bf' }}>
                    What's Included:
                  </div>
                  {pkg.features.map((feature, i) => (
                    <div key={i} className="flex items-start gap-2.5 text-xs sm:text-sm" style={{ color: '#9bb5bf' }}>
                      <div className="w-4 h-4 rounded-full flex items-center justify-center shrink-0 mt-0.5"
                        style={{ backgroundColor: pkg.popular ? 'rgba(90,60,98,0.3)' : 'rgba(73,132,150,0.2)', color: pkg.popular ? '#b88ac4' : '#89B7C2' }}>
                        <Check className="w-2.5 h-2.5 stroke-[3]" />
                      </div>
                      <span className="leading-snug">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-4 border-t" style={{ borderColor: 'rgba(137,183,194,0.1)' }}>
                <a
                  href="#calendar"
                  onClick={() => onSelectPackage(pkg.name)}
                  className="w-full py-3.5 px-4 rounded-xl text-xs sm:text-sm font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition-all text-white"
                  style={pkg.popular
                    ? { background: 'linear-gradient(135deg, #5A3C62, #7a4d85)', boxShadow: '0 8px 20px rgba(90,60,98,0.3)' }
                    : { background: 'linear-gradient(135deg, #3A6A6B, #498496)' }
                  }
                >
                  <span>Select & Check Date</span>
                  <ArrowRight className="w-4 h-4" />
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Custom inquiry */}
        <div className="mt-12 text-center p-6 rounded-2xl border max-w-2xl mx-auto"
          style={{ backgroundColor: 'rgba(255,255,255,0.02)', borderColor: 'rgba(137,183,194,0.1)' }}>
          <p className="text-sm" style={{ color: '#9bb5bf' }}>
            Need a custom package for a destination wedding or multi-day celebration?
          </p>
          <a
            href={`https://wa.me/${photographerConfig.whatsappNumber}?text=Hi%20Rana,%20I%20would%20like%20a%20customized%20wedding%20photography%20quote!`}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider mt-2 transition-colors"
            style={{ color: '#3A6A6B' }}
            onMouseEnter={e => e.currentTarget.style.color = '#89B7C2'}
            onMouseLeave={e => e.currentTarget.style.color = '#3A6A6B'}
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span>Chat With Rana for Custom Quote</span>
          </a>
        </div>

      </div>
    </section>
  );
}
